/* NepaliGarage — Navigation */
(function () {
    'use strict';

    const hamburger = document.getElementById('ng-hamburger');
    const nav       = document.querySelector('.ng-nav');
    const header    = document.getElementById('ng-header');

    // Mobile menu toggle
    if (hamburger && nav) {
        hamburger.addEventListener('click', function () {
            const isOpen = nav.classList.toggle('is-open');
            hamburger.classList.toggle('is-open', isOpen);
            hamburger.setAttribute('aria-expanded', String(isOpen));
        });

        // Close menu on outside click
        document.addEventListener('click', function (e) {
            if (!header.contains(e.target)) {
                nav.classList.remove('is-open');
                hamburger.classList.remove('is-open');
                hamburger.setAttribute('aria-expanded', 'false');
            }
        });
    }

    // User dropdown toggle
    const userTrigger  = document.getElementById('ng-user-trigger');
    const userDropdown = document.getElementById('ng-user-dropdown');

    if (userTrigger && userDropdown) {
        userTrigger.addEventListener('click', function () {
            const isOpen = userDropdown.hidden;
            userDropdown.hidden = !isOpen;
            userTrigger.setAttribute('aria-expanded', String(isOpen));
        });

        document.addEventListener('click', function (e) {
            if (!userTrigger.closest('.ng-user-menu').contains(e.target)) {
                userDropdown.hidden = true;
                userTrigger.setAttribute('aria-expanded', 'false');
            }
        });
    }

    // FAQ accordion
    document.querySelectorAll('.ng-faq__question').forEach(function (btn) {
        btn.addEventListener('click', function () {
            const answer  = btn.nextElementSibling;
            const isOpen  = btn.getAttribute('aria-expanded') === 'true';

            // Close all others
            document.querySelectorAll('.ng-faq__question').forEach(function (b) {
                b.setAttribute('aria-expanded', 'false');
                if (b.nextElementSibling) b.nextElementSibling.hidden = true;
            });

            if (!isOpen) {
                btn.setAttribute('aria-expanded', 'true');
                answer.hidden = false;
            }
        });
    });

    // ── Cookie consent (one-time) ─────────────────────────────────────────────
    var cookieBar     = document.getElementById('ng-cookie-bar');
    var cookieAccept  = document.getElementById('ng-cookie-accept');
    var cookieDecline = document.getElementById('ng-cookie-decline');

    if (cookieBar && !localStorage.getItem('ng_cookie_consent')) {
        cookieBar.hidden = false;
        setTimeout(function () { cookieBar.classList.add('is-visible'); }, 600);
    }

    function dismissCookieBar(decision) {
        localStorage.setItem('ng_cookie_consent', decision);
        cookieBar.classList.remove('is-visible');
        setTimeout(function () { cookieBar.hidden = true; }, 400);
    }

    if (cookieAccept)  cookieAccept.addEventListener('click',  function () { dismissCookieBar('accepted'); });
    if (cookieDecline) cookieDecline.addEventListener('click', function () { dismissCookieBar('declined'); });

})();
